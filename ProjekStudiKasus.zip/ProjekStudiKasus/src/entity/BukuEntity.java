
package entity;


public class BukuEntity {
    private int id;
    private String namaPenulis;
    private String judulBuku;
    private int halaman;

    public BukuEntity( int id, String namaPenulis, String judulBuku, int halaman) {
        this.id = id;
        this.namaPenulis = namaPenulis;
        this.judulBuku = judulBuku;
        this.halaman = halaman;
    }

    public BukuEntity() {
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    
    
    public String getNamaPenulis() {
        return namaPenulis;
    }
   
    public void setNamaPenulis(String namaPenulis) {
        this.namaPenulis = namaPenulis;
    }

    public String getJudulBuku() {
        return judulBuku;
    }

    public void setJudulBuku(String judulBuku) {
        this.judulBuku = judulBuku;
    }

    public int getHalaman() {
        return halaman;
    }

    public void setHalaman(int halaman) {
        this.halaman = halaman;
    }


    

}
