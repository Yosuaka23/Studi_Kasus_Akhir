package entity;
public class StaffEntity extends UserEntity{
    private String nama;
    private int id;

    public StaffEntity(int id, String nama, String username, String password) {
        super(username, password);
        this.nama = nama;
        this.id = id;
    }

//    public StaffEntity(String nama, String username, String password) {
//        super(username, password);
//        this.nama = nama;
//    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
       
    }
    
    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public void setUsername(String username) {
        this.username = username;
       
    }
    
    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public void setPassword(String password) {
        this.password = password;
       
    }
}
