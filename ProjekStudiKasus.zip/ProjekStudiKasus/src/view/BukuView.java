package view;
import controller.BukuController;
import entity.*;
import java.util.*;
import model.BukuModel;
import static model.BukuModel.getBukuList;

public class BukuView {
    Scanner input = new Scanner(System.in);
    BukuController buku = new BukuController();
    
    public void viewBuku(){
        ArrayList<BukuEntity>bukuList = buku.getList();
        
        if(bukuList.isEmpty()){
            System.out.println("DATA KOSONG");
            System.out.println("");
        }else{
            for(BukuEntity buku : bukuList){
                System.out.println("=============================");
                System.out.println("Id Penulis    :"+buku.getId());
                System.out.println("Nama Penulis  :"+buku.getNamaPenulis());
                System.out.println("Judul Buku    :"+buku.getJudulBuku());
                System.out.println("Halaman Buku  :"+buku.getHalaman());
                System.out.println("=============================");
            }
        }
    }
    public void inputBuku(){
        Scanner input = new Scanner(System.in);
        int id;
        String namaPenulis;
        String judulBuku;
        int halaman;
        System.out.println("Id Penulis             :");
        id = input.nextInt();
        input.nextLine();
        System.out.print("Masukan Nama Penulis     :");
        namaPenulis = input.nextLine();
        System.out.print("Masukan Judul Buku       :");
        judulBuku = input.nextLine();
        System.out.print("Masukan Jumlah Halaman   :");
        halaman = input.nextInt();
        BukuEntity bukuEntity = new BukuEntity(id, judulBuku, namaPenulis, halaman);
        bukuEntity.setId(id);
        bukuEntity.setNamaPenulis(namaPenulis);
        bukuEntity.setJudulBuku(judulBuku);
        bukuEntity.setHalaman(halaman);
        buku.insert(bukuEntity);
    }
    public void deleteBuku(){
        String inputString = input.nextLine();
        System.out.print("Pilih Id Penulis Yang Dihapus: ");
        int id = input.nextInt();
        buku.delete(id);
        }
    public void updateBuku(){  
        int menuBuku = 0;
        int id;
            do {
                System.out.print("Pilih ID Penulis yang akan diubah ");
                id = input.nextInt();

                System.out.print("1. Ganti Nama Penulis");
                System.out.print("2. Ganti Judul Buku");
                System.out.print("3. Ganti Halaman Buku");
                System.out.print("0. Exit");
                menuBuku = input.nextInt();
                input.nextLine();
                if (menuBuku == 1) {
                    System.out.print("Nama Penulis Baru ");
                   String namaPenulis = input.nextLine();
                    buku.updateNamaPenulis(id, namaPenulis);
                }else if(menuBuku == 2){
                    System.out.print("Username Staff Baru ");
                   String judulBuku = input.nextLine();
                    buku.updateJudulBuku(id, judulBuku);
                }else if(menuBuku == 3){
                     System.out.print("Password Staff Baru ");
                   int halamanaBuku = input.nextInt();
                    buku.updateHalamanBuku(id, halamanaBuku);
                }
            }while (menuBuku != 0);           
   }
    
}
