package view;
import java.util.Scanner;
import view.StaffView;
public class MenuView {
    Scanner input = new Scanner(System.in);
    
    StaffView staff = new StaffView();
    BukuView buku = new BukuView();


    public void run(){
        int pilih;
        do{
        System.out.println("Pilih Menu");
        System.out.println("1. Menu Stafff");
        System.out.println("2. Menu Buku");
        System.out.println("Masukan Pilihan :");
        pilih = input.nextInt();
        switch(pilih){
            case 1:
                menuStaff();
                break;
            case 2:
                menuBuku();
                break;
            case 3:
                
                break;
            
        }
            
        }while(pilih !=0);
    }
    
    
    public void menuStaff(){
        int pilih;
        do{
        System.out.println("Pilih Menu");
        System.out.println("1. Tambah Staff");
        System.out.println("2. Lihat Daftar Staff");
        System.out.println("3. Update Staff");
        System.out.println("4. Hapus Staff");
        System.out.println("5. Menu Utama");
        System.out.println("Masukan Pilihan :");
        pilih = input.nextInt();
        switch(pilih){
            case 1:
                staff.inputStaff();
                break;
            case 2:
                staff.viewStaff();
                break;
            case 3:
                staff.updateStaff();
                break;
            case 4:
                staff.deleteStaff();
                break;
            case 5:
                break;
            
        }
            
        }while(pilih !=5);
    }
    public void menuBuku(){
        int pilih;
        do{
        System.out.println("Pilih Menu");
        System.out.println("1. Tambah Nama Penulis");
        System.out.println("2. Lihat Data buku");
        System.out.println("3. Update Data Buku");
        System.out.println("4. Hapus Data Buku");
        System.out.println("5.Menu Utama");
        System.out.println("Masukan Pilihan :");
        pilih = input.nextInt();
        switch(pilih){
            case 1:
                buku.inputBuku();
                break;
            case 2:
                buku.viewBuku();
                break;
            case 3:
                buku.updateBuku();
                break;
            case 4:
                buku.deleteBuku();
                break;
            case 5:
                
                break;
            
        }
            
        }while(pilih !=5);
    }
    
}
