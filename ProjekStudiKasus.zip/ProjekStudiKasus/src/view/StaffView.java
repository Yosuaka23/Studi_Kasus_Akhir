
package view;
import controller.StaffController;
import entity.StaffEntity;
import java.util.ArrayList;
import java.util.Scanner;
import model.StaffModel;
import static model.StaffModel.getIndexStaff;

public class StaffView {
    Scanner input = new Scanner(System.in);
    StaffController staff = new StaffController();
    public void viewStaff(){
        ArrayList<StaffEntity>staffList = staff.getList();
        
        if(staffList.isEmpty()){
            System.out.println("DATA KOSONG");
            System.out.println("");
        }else{
            for(StaffEntity staff : staffList){
             System.out.println("Id Staff        :"+staff.getId());
             System.out.println("Nama Staff      :"+staff.getNama());
             System.out.println("Username Staff  :"+staff.getUsername());
             System.out.println("Password Staff  :"+staff.getPassword());
            }
        }
    }
    public void inputStaff(){
        int idStaff;
        String namaStaff;
        String usernameStaff;
        String passwordStaff;
        System.out.println("Masukan Id Staff       :");
        idStaff = input.nextInt();
        input.nextLine();
        System.out.print("Masukan Nama Staff       :");
        namaStaff = input.nextLine();
        System.out.print("Masukan Username Staff   :");
        usernameStaff = input.nextLine();
        System.out.print("Masukan Password Staff   :");
        passwordStaff = input.nextLine();
        StaffEntity staffEntity = new StaffEntity(idStaff, usernameStaff, passwordStaff, namaStaff);
        staffEntity.setId(idStaff);
        staffEntity.setNama(namaStaff);
        staffEntity.setUsername(usernameStaff);
        staffEntity.setPassword(passwordStaff);
        staff.insert(staffEntity);
        
    }
   public void deleteStaff(){
        int idstaff;
        System.out.print("Pilih id staff yang akan dihapus: ");
        int idStaff = input.nextInt();
        staff.delete(idStaff);
    }
   public void updateStaff(){  
        int menuBaru = 0;
        int id;
        
        do {
                System.out.print("Pilih ID Staff yang akan diubah ");
                id = input.nextInt();

                System.out.print("1. Ganti Nama Staff");
                System.out.print("2. Ganti Username Staff");
                System.out.print("3. Ganti Password");
                System.out.print("0. Exit");
                menuBaru = input.nextInt();
                input.nextLine();
                switch(menuBaru){
                    case 1:
                        System.out.print("Nama Staff Baru ");
                        String namaStaff = input.nextLine();
                        staff.updateNamaStaff( id, namaStaff);
                        break;
                    case 2:
                        System.out.print("Username Staff Baru ");
                        String usernameStaff = input.nextLine();
                        staff.updateUsernameStaff(id, usernameStaff);
                        break;
                    case 3:
                        System.out.print("Password Staff Baru ");
                        String passwordStaff = input.nextLine();
                        staff.updatePasswordStaff(id, passwordStaff);
                        break;
                }
            }while (menuBaru != 0);
   }

   
    
} 

