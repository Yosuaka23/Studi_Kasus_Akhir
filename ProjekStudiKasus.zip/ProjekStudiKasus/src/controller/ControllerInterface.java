
package controller;

import java.util.ArrayList;

public interface ControllerInterface {
 public void delete(int id);
}
