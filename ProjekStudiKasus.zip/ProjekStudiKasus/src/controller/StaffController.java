package controller;

import entity.StaffEntity;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import model.StaffModel;


public class StaffController implements ControllerInterface{
    public ArrayList<StaffEntity> getList(){
        return StaffModel.getStaffList();
    }
    public boolean insert(StaffEntity staff){
        return StaffModel.insertStaff(staff);
    }
    @Override
    public void delete(int id){
        StaffModel.deletStaff(id);
    }
    public void updateNamaStaff(int id, String nama){
        StaffModel.updateNamaStaff(id, nama);
    }
    
    public void updateUsernameStaff(int id, String username){
        StaffModel.updateUsernameStaff(id, username);
    }
    
    public void updatePasswordStaff(int id, String password){
        StaffModel.updatePasswordStaff(id, password);
    }
    
    public void updateAll(int id, StaffEntity staffUpdate){
        StaffModel.updateAll(0, staffUpdate);
    }
     public DefaultTableModel iniDataStaff(){
        StaffModel.initDataStaff();
        DefaultTableModel daftarStaff = new DefaultTableModel();
        Object [] kolom ={"ID STAFF", "NAMA STAFF", "USERNAME", "PASSWORD"};
        daftarStaff.setColumnIdentifiers(kolom);
        for (StaffEntity staff : getList()){
            Object [] row = new Object[kolom.length];
            row[0] = String.valueOf(staff.getId());
            row[1] = staff.getNama();
            row[2] = staff.getUsername();
            row[3] = staff.getPassword();
            daftarStaff.addRow(row);
        }
        return daftarStaff;
}
}
