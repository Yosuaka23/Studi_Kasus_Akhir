package controller;

import entity.BukuEntity;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import model.BukuModel;

public class BukuController implements ControllerInterface{
    
    public boolean addBuku(BukuEntity buku) {
        return BukuModel.addBuku(buku);
    }
     public boolean removeBuku(int id){
        return BukuModel.removeBuku(id);
    }

    public ArrayList<BukuEntity> getList() {
       return BukuModel.getBukuList();
    }
    public boolean insert(BukuEntity buku){
        return BukuModel.insertBuku(buku);
    }
  @Override
    public void delete(int id){
        BukuModel.deleteBuku(id);
    }
    public void updateNamaPenulis(int id, String namaPenulis){
        BukuModel.updatePenulisBuku(id, namaPenulis);
    }
    public void updateJudulBuku(int id, String judulBuku){
        BukuModel.updateJudulBuku(id, judulBuku);
    }
    public void updateHalamanBuku(int id, int halaman){
        BukuModel.updateHalamanBuku(id, halaman);
    }

    public DefaultTableModel iniData(){
        BukuModel.iniData();
        DefaultTableModel daftarBuku = new DefaultTableModel();
        Object [] kolom ={"ID PENULIS", "NAMA PENULIS", "JUDUL BUKU", "HALAMAN"};
        daftarBuku.setColumnIdentifiers(kolom);
        for (BukuEntity buku : getList()){
            Object [] row = new Object[kolom.length];
            row[0] = buku.getId();
            row[1] = buku.getNamaPenulis();
            row[2] = buku.getJudulBuku();
            row[3] = buku.getHalaman();
            daftarBuku.addRow(row);
        }
        return daftarBuku;
}
    public BukuEntity getJudulByBuku(String judulBuku){
        return BukuModel.getBukuByJudul(judulBuku);
    }
}


