import java.util.*;
import model.BukuModel;
import view.*;
import viewGui.*;
import viewGui.staff.InsertStaff;
import viewgui.ReadBukuGui;
import viewGui.staff.ReadStaffGui;
import viewGui.staff.UpdateStaff;

public class ProjekStudiKasus {    
    static Scanner input = new Scanner(System.in);
    public static void main(String[] args) {
//        BukuModel.initData();
//        MenuView app = new MenuView();
//        app.run();
//        InsertBuku insertbuku = new InsertBuku();
//        insertbuku.setVisible(true);

//        ReadBukuGui buku = new ReadBukuGui();
//        buku.setVisible(true);

//         PilihMenu menu = new PilihMenu();
//         menu.setVisible(true);

        ReadStaffGui staff = new ReadStaffGui();
        staff.setVisible(true);
////        
//          InsertStaff insertstaff = new InsertStaff();
//          insertstaff.setVisible(true);
        
//            UpdateStaff updatestaff = new UpdateStaff();
//            updatestaff.setVisible(true);

//            UpdateBuku updatebuku = new UpdateBuku();
//            updatebuku.setVisible(true);
          
        
    }
}
