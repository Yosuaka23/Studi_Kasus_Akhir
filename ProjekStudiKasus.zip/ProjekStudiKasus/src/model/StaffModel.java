package model;
import java.util.*;
import java.util.ArrayList;
import entity.StaffEntity;
public class StaffModel {
   
    static ArrayList<StaffEntity> staffEntityArrayList = new ArrayList<>();
    static Scanner input = new Scanner(System.in);
    
    public static void initDataStaff(){
    staffEntityArrayList.add(new StaffEntity(1, "Yosua", "Yosh", "1234"));
    staffEntityArrayList.add(new StaffEntity(2, "Desinta", "Sinta", "12345"));
    staffEntityArrayList.add(new StaffEntity(3, "Adimas", "Deka", "123456"));
    staffEntityArrayList.add(new StaffEntity(4, "Zufar", "Sohek", "1234567"));
    staffEntityArrayList.add(new StaffEntity(5, "Dimas", "Dimbro", "12345678"));
   }
    public static ArrayList<StaffEntity> getStaffList(){
        return staffEntityArrayList;
    }
    
    
    public static boolean insertStaff(StaffEntity staff){
        return staffEntityArrayList.add(staff);
    }
    
    public static void deletStaff(int idStaff){
        int index = getIndexStaff(staffEntityArrayList, idStaff);
        staffEntityArrayList.remove(index);
    } 
     
    public static void updateNamaStaff(int idStaffEntity, String nama){
         staffEntityArrayList.get(getIndexStaff(staffEntityArrayList, idStaffEntity)).setNama(nama);
    }
    public static void updateUsernameStaff(int idStaffEntity, String username){
        staffEntityArrayList.get(getIndexStaff(staffEntityArrayList, idStaffEntity)).setUsername(username);
    }
    public static void updatePasswordStaff(int idStaffEntity, String password){
        staffEntityArrayList.get(getIndexStaff(staffEntityArrayList, idStaffEntity)).setPassword(password);
    }
    public static void updateAll(int idStaff, StaffEntity staffUpdate){
        staffEntityArrayList.set(getIndexStaff(staffEntityArrayList, idStaff), staffUpdate);
    }
     
      
      public static int getIndexStaff(ArrayList<StaffEntity> staffEntityArrayList, int idStaff) {
        int index = -1;
        if(staffEntityArrayList.isEmpty()){
            System.out.println("DATA KOSONG");
        }
        else{
            for(StaffEntity staffEntity : staffEntityArrayList){
                if(staffEntity.getId() == idStaff){
                    index = staffEntityArrayList.indexOf(staffEntity);   
                }
            }
        }
        return index;
    }
}
    
