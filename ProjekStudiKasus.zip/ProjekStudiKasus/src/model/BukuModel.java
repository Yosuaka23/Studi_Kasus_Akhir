
package model;

import entity.BukuEntity;
import java.util.ArrayList;
import java.util.Scanner;
import static model.BukuModel.iniData;


public class BukuModel {
   static ArrayList<BukuEntity> bukuEntityArrayList = new ArrayList<>();
   static Scanner input = new Scanner(System.in);
   public static void iniData(){
        bukuEntityArrayList.add(new BukuEntity(1, "yo", "mtk", 50));
        bukuEntityArrayList.add(new BukuEntity(2, "yo1", "ipa", 50));
        bukuEntityArrayList.add(new BukuEntity(3, "yo2", "bindo", 50));
        bukuEntityArrayList.add(new BukuEntity(4, "yo3", "bing", 50));
        bukuEntityArrayList.add(new BukuEntity(5, "yo4", "ips", 50));
    }
    public static boolean removeBuku(int id){
    int index = getIndexBuku(id);
    boolean status = false;
    if (index != -1){
    bukuEntityArrayList.remove(index);
    status = true;
    }
    return status;
    }
   public static boolean addBuku(BukuEntity bukuEntity){
    boolean status = false;
    if (bukuEntity != null){
    bukuEntityArrayList.add(bukuEntity);
    status = true;
    }
    return status;
    }
    public static ArrayList<BukuEntity> getBukuList(){
        return bukuEntityArrayList;
    }
    public static boolean insertBuku(BukuEntity buku){
        return bukuEntityArrayList.add(buku);
    }
     public static void deleteBuku(int idBuku){
        int index = getIndexBuku(bukuEntityArrayList, idBuku);
        bukuEntityArrayList.remove(index);
    } 
    public static void updatePenulisBuku(int idBukuEntity, String namaPenulis){
         bukuEntityArrayList.get(getIndexBuku(bukuEntityArrayList, idBukuEntity)).setNamaPenulis(namaPenulis);
    }
    public static void updateJudulBuku(int idBukuEntity, String judulBuku){
        bukuEntityArrayList.get(getIndexBuku(bukuEntityArrayList, idBukuEntity)).setJudulBuku(judulBuku);
    }
    public static void updateHalamanBuku(int idBukuEntity, int halaman){
        bukuEntityArrayList.get(getIndexBuku(bukuEntityArrayList, idBukuEntity)).setHalaman(halaman);
    }
     public static BukuEntity getBukuByJudul(String judulBuku){
        BukuEntity buku = null;
        for (BukuEntity bukuEntity: bukuEntityArrayList) {
            if (bukuEntity.getJudulBuku().equals(judulBuku)){
                buku = bukuEntity;
            }
        }
        return buku;
    }
     
    public static int getIndexBuku(ArrayList<BukuEntity> bukuEntityArrayList, int id) {
        int index = -1;
        if(bukuEntityArrayList.isEmpty()){
            System.out.println("DATA KOSONG");
        }
        else{
            for(BukuEntity bukuEntity:bukuEntityArrayList){
                if(bukuEntity.getId() == id){
                    index = bukuEntityArrayList.indexOf(bukuEntity);   
                }
            }
        }
        return index;
    }

   
}
