package viewGui;


import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class PilihMenu extends JFrame{//wajib extends Jframe
    private final JLabel judulLbl;
    private final JButton staff;
    private final JButton buku;
    {
        judulLbl = new JLabel("MANAGEMENT LIBRARY");
       
        
        staff = new JButton("MENU STAFF");
        buku = new JButton("MENU BUKU");
    }

    public PilihMenu() {
        initWindow();
        initComponent();
    }
    private void initWindow(){//frame
        setTitle("YOSUA");
        setSize(800, 600);
        setLayout(null);
        getContentPane().setBackground(Color.gray);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }
    private void initComponent(){//component
        judulLbl.setBounds(320, 21, 250, 30);
        judulLbl.setFont(new Font("Times New Roman", Font.BOLD, 15));
        add(judulLbl);
        
        staff.setBounds(176, 100, 150, 60);
        staff.setFont(new Font("Times New Roman", Font.BOLD,12));
        staff.setBackground(Color.WHITE);
        add(staff);
        
        buku.setBounds(430, 100, 150, 60);
        buku.setFont(new Font("Times New Roman", Font.BOLD,12));
        buku.setBackground(Color.white);
        add(buku);
        
        CreatCheck();
        
    }

    private void CreatCheck() {
        
    }
}
