package viewGui;
import controller.BukuController;
import entity.BukuEntity;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class InsertBuku extends JFrame{//wajib extends Jframe
    private JLabel judulLbl, idLbl, judulBukuLbl, penulisLbl, halamanLbl;
    private JTextField idP, judul, penulis, halamanB;
    private JButton submit, reset;
    {
        judulLbl = new JLabel("INPUT BUKU");
        
        idLbl = new JLabel("ID PENULIS");
        penulisLbl = new JLabel("PENULIS");
        judulBukuLbl = new JLabel("JUDUL BUKU");
        halamanLbl = new JLabel("HALAMAN");
        idP = new JTextField("MASUKKAN ID");
        penulis = new JTextField("MASUKKAN PENULIS");
        judul = new JTextField("MASUKKAN JUDUL");
        halamanB = new JTextField("MASUKKAN HALAMAN");
        
        submit = new JButton("SUBMIT");
        reset = new JButton("RESET");
    }

    public InsertBuku() {
        initWindow();
        initComponent();
    }
    private void initWindow(){//frame
        setTitle("YOSUA");
        setSize(800, 600);
        setLayout(null);
        getContentPane().setBackground(Color.LIGHT_GRAY);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }
    private void initComponent(){//component
        judulLbl.setBounds(320, 21, 250, 30);
        judulLbl.setFont(new Font("Times New Roman", Font.BOLD, 15));
        add(judulLbl);
        
        idLbl.setBounds(340, 70, 250, 30);
        idLbl.setFont(new Font("Times New Roman", Font.BOLD,12));
        add(idLbl);
        idP.setBounds(176, 96, 400, 55);
        add(idP);
        
        penulisLbl.setBounds(347, 160, 250, 30);
        penulisLbl.setFont(new Font("Times New Roman", Font.BOLD,12));
        add(penulisLbl);
        penulis.setBounds(176, 180, 400, 55); //TEXT FIELD
        add(penulis);
        
        judulBukuLbl.setBounds(340, 244, 250, 30); //LABEL
        judulBukuLbl.setFont(new Font("Times New Roman", Font.BOLD,12));  //LABEL
        add(judulBukuLbl);
        judul.setBounds(176, 264, 400, 55); //TEXT FIELD
        add(judul);
        
        halamanLbl.setBounds(340, 324, 250, 30); //LABEL
        halamanLbl.setFont(new Font("Times New Roman", Font.BOLD,12));  //LABEL
        add(halamanLbl);
        halamanB.setBounds(176, 348, 400, 55); //TEXT FIELD
        add(halamanB);
        
        submit.setBounds(176, 420, 150, 60);
        submit.setFont(new Font("Times New Roman", Font.BOLD,12));
        submit.setBackground(Color.GRAY);
        add(submit);
        
        reset.setBounds(430, 420, 150, 60);
        reset.setFont(new Font("Times New Roman", Font.BOLD,12));
        reset.setBackground(Color.GRAY);
        add(reset);
        
      
    }

    private void cancelEvent(){
        reset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                dispose();
            }
        });
    }

    private void createEvent(){
        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(idP.getText());
                    String namaPenulis = penulis.getText();
                    String judulBuku = judul.getText();
                    int halaman = Integer.parseInt(halamanB.getText());
                    BukuController.addBuku(new BukuEntity(id,namaPenulis,judulBuku,halaman));
                    JOptionPane.showMessageDialog(null, "Tambah Buku Sukses ", "information", JOptionPane.INFORMATION_MESSAGE);
                    new ReadBukuGui().setVisible(true);
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(null, "Format Penulisan Salah", "Tambah Buku Gagal", JOptionPane.INFORMATION_MESSAGE);
                    reset();
                }
            }
        });
    }
    void reset(){
        idP.setText(null);
        penulis.setText(null);
        judul.setText(null);
        halamanB.setText(null);
    }
}
