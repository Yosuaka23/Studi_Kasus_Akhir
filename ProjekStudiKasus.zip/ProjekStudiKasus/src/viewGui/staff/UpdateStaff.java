package viewGui.staff;
import controller.StaffController;
import entity.StaffEntity;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class UpdateStaff extends JFrame{//wajib extends Jframe
    private StaffController staffController = new StaffController();
    private int id;
    private final JLabel judulLbl, namaStaffLbl, usernameStaffLbl, passwordStaffLbl;
    private final JTextField namaStaff, usernameStaff, passwordStaff;
    private final JButton submit;
    private final JButton reset;
    {
        judulLbl = new JLabel("UPDATE DATA STAFF");
        
        
        namaStaffLbl = new JLabel("NAMA STAFF");
        usernameStaffLbl = new JLabel("USERNAME STAFF");
        passwordStaffLbl = new JLabel("PASSWORD STAFF");
        namaStaff = new JTextField(staffController.getList().get(id).getNama());
        usernameStaff = new JTextField(staffController.getList().get(id).getUsername());
        passwordStaff = new JTextField(staffController.getList().get(id).getPassword());
        
        submit = new JButton("SUBMIT");
        reset = new JButton("RESET");
    }

    public UpdateStaff(int id) {
        this.id = id;
        initWindow();
        initComponent();
    }
    private void initWindow(){//frame
        setTitle("YOSUA");
        setSize(800, 600);
        setLayout(null);
        getContentPane().setBackground(Color.CYAN);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }
    private void initComponent(){//component
        judulLbl.setBounds(320, 21, 250, 30);
        judulLbl.setFont(new Font("Times New Roman", Font.BOLD, 15));
        add(judulLbl);
        
        namaStaffLbl.setBounds(347, 70, 250, 30);
        namaStaffLbl.setFont(new Font("Times New Roman", Font.BOLD,12));
        add(namaStaffLbl);
        namaStaff.setBounds(176, 96, 400, 55); //TEXT FIELD
        add(namaStaff);
        
        usernameStaffLbl.setBounds(340, 160, 250, 30); //LABEL
        usernameStaffLbl.setFont(new Font("Times New Roman", Font.BOLD,12));  //LABEL
        add(usernameStaffLbl);
        usernameStaff.setBounds(176, 180, 400, 55); //TEXT FIELD
        add(usernameStaff);
        
        passwordStaffLbl.setBounds(340, 244, 250, 30); //LABEL
        passwordStaffLbl.setFont(new Font("Times New Roman", Font.BOLD,12));  //LABEL
        add(passwordStaffLbl);
        passwordStaff.setBounds(176, 264, 400, 55); //TEXT FIELD
        add(passwordStaff);
        
        submit.setBounds(176, 348, 150, 60);
        submit.setFont(new Font("Times New Roman", Font.BOLD,12));
        submit.setBackground(Color.GRAY);
        add(submit);
        
        reset.setBounds(430, 348, 150, 60);
        reset.setFont(new Font("Times New Roman", Font.BOLD,12));
        reset.setBackground(Color.GRAY);
        add(reset);
        
        submitEvent();
        
    }

    private void submitEvent() {
        submit.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                if((namaStaff.getText().length() == 0) || (usernameStaff.getText().length() == 0) || (passwordStaff.getText().length() == 0)){
                    staffController.updateAll(id, new StaffEntity(id, usernameStaff.getText(), namaStaff.getText(), passwordStaff.getText()));
                    new ReadStaffGui().setVisible(true);
                    dispose();
                }
                else{
                    JOptionPane.showMessageDialog(null, "INPUTAN TIDAK BOLEH KOSONG");
                }
            }
        });
    }
}
