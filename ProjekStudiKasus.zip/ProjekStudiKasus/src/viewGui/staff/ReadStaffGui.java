package viewGui.staff;

import controller.StaffController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ReadStaffGui extends JFrame{
    private final StaffController staffController = new StaffController();
    private final JScrollPane scrollPane;
    private final JTable table;
    private final JButton update;
    private final JButton hapus;
    private final JTextField tabelDipilih;
    {
        table = new JTable();
        scrollPane = new JScrollPane(table);
        update = new JButton("UPDATE");
        hapus = new JButton("DELETE");
        tabelDipilih = new JTextField();
    }
    public ReadStaffGui() {
        initWindow();
        initComponent();
    }
    public void initWindow(){
        setTitle("YOSUA");
        setSize(1000, 600);
        setLayout(null);
        getContentPane().setBackground(Color.darkGray);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }
    public void initComponent(){
        scrollPane.setBounds(45, 50, 900, 300);
        dataTable();
        add(scrollPane);
        
        update.setBounds(300, 370, 150, 60);
        update.setFont(new Font("Times New Roman", Font.BOLD,12));
        update.setBackground(Color.GRAY);
        add(update);
        
        hapus.setBounds(600, 370, 150, 60);
        hapus.setFont(new Font("Times New Roman", Font.BOLD,12));
        hapus.setBackground(Color.GRAY);
        add(hapus);
        
        
        tableEvent();
        updateEvent();
    }

    private void dataTable(){
        table.setModel(staffController.iniDataStaff());
        table.setDefaultEditor(Object.class, null);
        table.setBackground(Color.LIGHT_GRAY);
    }
    
    public void tableEvent(){
        table.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e){
                int i = table.getSelectedRow();
                tabelDipilih.setText(staffController.iniDataStaff().getValueAt(i, 0).toString());
            }
        });
    }
    
    public void updateEvent(){
        update.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                if(tabelDipilih.getText().length() > 0){
                    new UpdateStaff(Integer.valueOf(tabelDipilih.getText())).setVisible(true);
                    dispose();
                }
                else{
                    JOptionPane.showMessageDialog(null, "PILIH DATA DULU");
                }
            }
        });
    }
}
