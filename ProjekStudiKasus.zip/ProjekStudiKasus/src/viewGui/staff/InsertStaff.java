package viewGui.staff;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class InsertStaff extends JFrame{//wajib extends Jframe
    private final JLabel judulLbl, idLbl, namaStaffLbl, usernameStaffLbl, passwordStaffLbl;
    private final JTextField id, namaStaff, usernameStaff, passwordStaff;
    private final JButton submit;
    private final JButton reset;
    {
        judulLbl = new JLabel("INPUT DATA STAFF");
        
        idLbl = new JLabel("ID STAFF");
        namaStaffLbl = new JLabel("NAMA STAFF");
        usernameStaffLbl = new JLabel("USERNAME STAFF");
        passwordStaffLbl = new JLabel("PASSWORD STAFF");
        id = new JTextField("MASUKKAN ID");
        namaStaff = new JTextField("MASUKKAN NAMA STAFF");
        usernameStaff = new JTextField("MASUKKAN USERNAME STAFF");
        passwordStaff = new JTextField("MASUKKAN PASSWORD");
        
        submit = new JButton("SUBMIT");
        reset = new JButton("RESET");
    }

    public InsertStaff() {
        initWindow();
        initComponent();
    }
    private void initWindow(){//frame
        setTitle("YOSUA");
        setSize(800, 600);
        setLayout(null);
        getContentPane().setBackground(Color.DARK_GRAY);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }
    private void initComponent(){//component
        judulLbl.setBounds(320, 21, 250, 30);
        judulLbl.setFont(new Font("Times New Roman", Font.BOLD, 15));
        add(judulLbl);
        
        idLbl.setBounds(340, 70, 250, 30);
        idLbl.setFont(new Font("Times New Roman", Font.BOLD,12));
        add(idLbl);
        id.setBounds(176, 96, 400, 55);
        add(id);
        
        namaStaffLbl.setBounds(347, 160, 250, 30);
        namaStaffLbl.setFont(new Font("Times New Roman", Font.BOLD,12));
        add(namaStaffLbl);
        namaStaff.setBounds(176, 180, 400, 55); //TEXT FIELD
        add(namaStaff);
        
        usernameStaffLbl.setBounds(340, 244, 250, 30); //LABEL
        usernameStaffLbl.setFont(new Font("Times New Roman", Font.BOLD,12));  //LABEL
        add(usernameStaffLbl);
        usernameStaff.setBounds(176, 264, 400, 55); //TEXT FIELD
        add(usernameStaff);
        
        passwordStaffLbl.setBounds(340, 324, 250, 30); //LABEL
        passwordStaffLbl.setFont(new Font("Times New Roman", Font.BOLD,12));  //LABEL
        add(passwordStaffLbl);
        passwordStaff.setBounds(176, 348, 400, 55); //TEXT FIELD
        add(passwordStaff);
        
        submit.setBounds(176, 420, 150, 60);
        submit.setFont(new Font("Times New Roman", Font.BOLD,12));
        submit.setBackground(Color.GRAY);
        add(submit);
        
        reset.setBounds(430, 420, 150, 60);
        reset.setFont(new Font("Times New Roman", Font.BOLD,12));
        reset.setBackground(Color.GRAY);
        add(reset);
        
        CreatCheckStaff();
        
    }

    private void CreatCheckStaff() {
        
    }
}
