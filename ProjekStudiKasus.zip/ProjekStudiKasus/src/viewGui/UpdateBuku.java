package viewGui;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class UpdateBuku extends JFrame{//wajib extends Jframe
    private final JLabel judulLbl, penulisLbl, judulBukuLbl, halamanLbl;
    private final JTextField penulis, judulBuku, halaman;
    private final JButton submit;
    private final JButton reset;
    {
        judulLbl = new JLabel("UPDATE BUKU STAFF");
        
        penulisLbl = new JLabel("NAMA PENULIS");
        judulBukuLbl = new JLabel("JUDUL BUKU");
        halamanLbl = new JLabel("JUMLAH HALAMAN");
        penulis = new JTextField("MASUKKAN NAMA PENULIS");
        judulBuku = new JTextField("MASUKKAN JUDUL BUKU");
        halaman = new JTextField("MASUKKAN JUMLAH BUKU");
        
        submit = new JButton("SUBMIT");
        reset = new JButton("RESET");
    }

    public UpdateBuku() {
        initWindow();
        initComponent();
    }
    private void initWindow(){//frame
        setTitle("YOSUA");
        setSize(800, 600);
        setLayout(null);
        getContentPane().setBackground(Color.YELLOW);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }
    private void initComponent(){//component
        judulLbl.setBounds(320, 21, 250, 30);
        judulLbl.setFont(new Font("Times New Roman", Font.BOLD, 15));
        add(judulLbl);
        
        penulisLbl.setBounds(347, 70, 250, 30);
        penulisLbl.setFont(new Font("Times New Roman", Font.BOLD,12));
        add(penulisLbl);
        penulis.setBounds(176, 96, 400, 55); //TEXT FIELD
        add(penulis);
        
        judulBukuLbl.setBounds(340, 160, 250, 30); //LABEL
        judulBukuLbl.setFont(new Font("Times New Roman", Font.BOLD,12));  //LABEL
        add(judulBukuLbl);
        judulBuku.setBounds(176, 180, 400, 55); //TEXT FIELD
        add(judulBuku);
        
        halamanLbl.setBounds(340, 244, 250, 30); //LABEL
        halamanLbl.setFont(new Font("Times New Roman", Font.BOLD,12));  //LABEL
        add(halamanLbl);
        halaman.setBounds(176, 264, 400, 55); //TEXT FIELD
        add(halaman);
        
        submit.setBounds(176, 348, 150, 60);
        submit.setFont(new Font("Times New Roman", Font.BOLD,12));
        submit.setBackground(Color.GRAY);
        add(submit);
        
        reset.setBounds(430, 348, 150, 60);
        reset.setFont(new Font("Times New Roman", Font.BOLD,12));
        reset.setBackground(Color.GRAY);
        add(reset);
        
        CreatCheckStaff();
        
    }

    private void CreatCheckStaff() {
        
    }
}
