package viewgui;

import controller.BukuController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ReadBukuGui extends JFrame{
    private BukuController bukuController = new BukuController();
    private final JScrollPane scrollPane;
    private final JTable table;
    private JButton update;
    private JButton hapus;
    {
        table = new JTable();
        scrollPane = new JScrollPane(table);
        update = new JButton("UPDATE");
        hapus = new JButton("DELETE");
    }
    public ReadBukuGui() {
        initWindow();
        initComponent();
    }
    public void initWindow(){
        setTitle("YOSUA");
        setSize(1000, 600);
        setLayout(null);
        getContentPane().setBackground(Color.darkGray);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }
    public void initComponent(){
        scrollPane.setBounds(45, 50, 900, 300);
        dataTable();
        add(scrollPane);
        
        update.setBounds(300, 370, 150, 60);
        update.setFont(new Font("Times New Roman", Font.BOLD,12));
        update.setBackground(Color.GRAY);
        add(update);
        
        hapus.setBounds(600, 370, 150, 60);
        hapus.setFont(new Font("Times New Roman", Font.BOLD,12));
        hapus.setBackground(Color.GRAY);
        add(hapus);
    }

    private void deleteEvent(){
        deleteBukubtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!selectedJudul.equals("null")){
                    int konf = JOptionPane.showConfirmDialog(null, "Yakin ingin hapus yang dipilih ");

                    if (konf == JOptionPane.YES_OPTION) {
                        boolean hapus = bukuController.removeBuku(selectedJudul);
                        table.setModel(createTableModel());
                        selectedJudul = "null";
                        String msg = (hapus == true) ? "Berhasil Hapus Data" : "Gagal Hapus Data";
                        JOptionPane.showMessageDialog(null, msg);
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "Cancelled");

                    }
                }
                else {
                    JOptionPane.showMessageDialog(null, "PILIH DATA TERLEBIH DAHULU");
                }
            }
        });

    }
    private void dataTable(){
        table.setModel(bukuController.iniData());
        table.setDefaultEditor(Object.class, null);
        table.setBackground(Color.LIGHT_GRAY);
    }
}
